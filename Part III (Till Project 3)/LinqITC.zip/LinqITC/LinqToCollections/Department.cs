﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqToCollections
{
    class Department
    {
        public int Deptid { get; set; }
        public string Dname { get; set; }
        public int Dhead { get; set; }
    }
}
